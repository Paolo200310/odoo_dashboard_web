
from flask import Flask, render_template
import psycopg2

app = Flask(__name__)

def get_counts():
    conn = psycopg2.connect(
        dbname="db_odoo",
        user="odoo",
        password="odoo",
        host="localhost",
        port="5432"
    )
    cur = conn.cursor()

    def count(table):
        try:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            return cur.fetchone()[0]
        except:
            return 0

    data = {
        "academic": {
            "tables": {
                "academic_student": count("academic_student"),
                "academic_subject": count("academic_subject")
            }
        },
        "administrativo": {
            "tables": {
                "hr_employee": count("hr_employee"),
                "hr_department": count("hr_department")
            }
        },
        "transaccional": {
            "tables": {
                "purchase_order": count("purchase_order"),
                "sale_order": count("sale_order")
            }
        },
        "financiero": {
            "tables": {
                "purchase_order": count("purchase_order"),
                "sale_order": count("sale_order")
            }
        }
    }

    cur.close()
    conn.close()
    return data

@app.route("/")
def dashboard():
    data = get_counts()
    totals = {
        "academic": sum(data["academic"]["tables"].values()),
        "administrativo": sum(data["administrativo"]["tables"].values()),
        "transaccional": sum(data["transaccional"]["tables"].values()),
        "financiero": sum(data["financiero"]["tables"].values())
    }
    return render_template("dashboard.html", data=data, totals=totals)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
