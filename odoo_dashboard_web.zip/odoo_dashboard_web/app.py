
from flask import Flask, render_template
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)

@app.route('/')
def index():
    conn = psycopg2.connect(
        host="localhost",
        database="odoo",
        user="odoo",
        password="odoo",
        port=5432
    )
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")
    tables = cur.fetchall()
    data = {}
    for table in tables:
        table_name = table['table_name']
        try:
            cur.execute(f"SELECT COUNT(*) FROM {table_name}")
            count = cur.fetchone()['count']
            data[table_name] = {'labels': [table_name], 'counts': [count]}
        except Exception as e:
            continue
    cur.close()
    conn.close()
    return render_template('index.html', data=data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
