
from flask import Flask, render_template
import psycopg2

app = Flask(__name__)

DB_PARAMS = {
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': 5432
}

@app.route("/")
def dashboard():
    categories = {
        "Módulo Académico": ["academic_student", "academic_subject"],
        "Administrativo": ["hr_employee", "hr_department"],
        "Transaccional": ["purchase_order", "sale_order"],
        "Financiero": ["purchase_order", "sale_order"]  # Cálculo manual
    }

    data = []
    try:
        conn = psycopg2.connect(**DB_PARAMS)
        cur = conn.cursor()

        for name, tables in categories.items():
            total = 0
            details = {}
            for table in tables:
                try:
                    cur.execute(f"SELECT COUNT(*) FROM {table}")
                    count = cur.fetchone()[0]
                    details[table] = count
                    total += count
                except Exception as e:
                    details[table] = "Tabla no encontrada"
            # Calcular presupuesto si es Financiero
            if name == "Financiero":
                ingresos = details.get("sale_order", 0)
                gastos = details.get("purchase_order", 0)
                presupuesto = ingresos - gastos
                data.append({'name': name, 'total': presupuesto, 'details': details})
            else:
                data.append({'name': name, 'total': total, 'details': details})

        cur.close()
        conn.close()
    except Exception as e:
        print("ERROR:", e)
    return render_template("dashboard.html", data=data)
    
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
