from flask import Flask, render_template
import psycopg2

app = Flask(__name__)

DB_PARAMS = {
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': 5432
}

MODULE_TABLES = {
    'Academic': ['academic_student', 'academic_subject'],
    'Administrativo': ['hr_employee', 'hr_department'],
    'Transaccional': ['purchase_order', 'sale_order'],
    'Financiero': ['purchase_order', 'sale_order']
}

def get_table_counts(tables):
    data = {}
    try:
        conn = psycopg2.connect(**DB_PARAMS)
        cur = conn.cursor()
        for table in tables:
            try:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                count = cur.fetchone()[0]
                data[table] = count
            except Exception:
                data[table] = 0
        cur.close()
        conn.close()
    except Exception as e:
        print("DB Error:", e)
    return data

@app.route("/")
def index():
    module_data = {}
    totals = {}
    for module, tables in MODULE_TABLES.items():
        data = get_table_counts(tables)
        module_data[module] = data
        totals[module] = sum(data.values())
    return render_template("dashboard.html", data=module_data, totals=totals)

@app.route("/stats/<module>")
def stats(module):
    tables = MODULE_TABLES.get(module, [])
    data = get_table_counts(tables)
    return render_template("stats.html", module=module, data=data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
