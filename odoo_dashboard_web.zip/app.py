
from flask import Flask, render_template
import psycopg2

app = Flask(__name__)

DB_CONFIG = {
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': 5432
}

TABLES_BY_MODULE = {
    "academic": ["academic_student", "academic_subject"],
    "administrativo": ["hr_employee", "hr_department"],
    "transaccional": ["purchase_order", "sale_order"],
    "financiero": ["purchase_order", "sale_order"]
}

def count_records(table):
    try:
        with psycopg2.connect(**DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                return cur.fetchone()[0]
    except Exception:
        return 0

@app.route('/')
def index():
    data = {}
    for module, tables in TABLES_BY_MODULE.items():
        data[module] = {table: count_records(table) for table in tables}
    totals = {k: sum(v.values()) for k, v in data.items()}
    return render_template('index.html', data=data, totals=totals)

@app.route('/estadisticas/<modulo>')
def estadisticas(modulo):
    tablas = TABLES_BY_MODULE.get(modulo, [])
    datos = {tabla: count_records(tabla) for tabla in tablas}
    return render_template('estadisticas.html', modulo=modulo.capitalize(), datos=datos)

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
