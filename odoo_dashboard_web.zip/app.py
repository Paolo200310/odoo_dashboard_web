from flask import Flask, render_template, redirect, url_for
import psycopg2
import matplotlib.pyplot as plt
import os

app = Flask(__name__)
DB_PARAMS = {{
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': 5432
}}

MODULES = {{
    'academic': ['academic_student', 'academic_subject'],
    'administrativo': ['hr_employee', 'hr_department'],
    'transaccional': ['purchase_order', 'sale_order'],
    'financiero': ['purchase_order', 'sale_order']
}}

def get_count(table):
    try:
        with psycopg2.connect(**DB_PARAMS) as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                return cur.fetchone()[0]
    except:
        return 0

def generate_chart(module_name, tables):
    values = [get_count(t) for t in tables]
    plt.figure(figsize=(5,3))
    plt.bar(tables, values, color='skyblue')
    plt.title(f'Registros por tabla - {module_name.capitalize()}')
    plt.tight_layout()
    chart_path = f"static/{module_name}_chart.png"
    plt.savefig(os.path.join(os.getcwd(), chart_path))
    plt.close()
    return chart_path

@app.route("/")
def index():
    data = {{}}
    total = {{}}
    for mod, tables in MODULES.items():
        data[mod] = {{tbl: get_count(tbl) for tbl in tables}}
        total[mod] = sum(data[mod].values())
    return render_template("index.html", data=data, total=total)

@app.route("/<module>")
def module_stats(module):
    if module not in MODULES:
        return redirect(url_for('index'))
    tables = MODULES[module]
    table_data = {{tbl: get_count(tbl) for tbl in tables}}
    chart = generate_chart(module, tables)
    return render_template("module_stats.html", module=module, table_data=table_data, chart=chart)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
