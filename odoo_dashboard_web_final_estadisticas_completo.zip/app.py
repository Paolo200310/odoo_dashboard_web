
from flask import Flask, render_template
import psycopg2
import plotly.graph_objs as go
import plotly.io as pio

app = Flask(__name__)

DB_PARAMS = {
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': '5432'
}

MODULES = {
    'Academic': ['academic_student', 'academic_subject'],
    'Administrativo': ['hr_employee', 'hr_department'],
    'Transaccional': ['purchase_order', 'sale_order'],
    'Financiero': ['financial_summary']
}

DISPLAY_NAMES = {
    'academic_student': 'Estudiantes Totales',
    'academic_subject': 'Materias',
    'hr_employee': 'Empleados',
    'hr_department': 'Departamentos',
    'purchase_order': 'Órdenes de Compra',
    'sale_order': 'Órdenes de Venta',
    'financial_summary': 'Resumen Financiero'
}

def get_table_counts():
    conn = psycopg2.connect(**DB_PARAMS)
    cur = conn.cursor()
    data = {}

    for module, tables in MODULES.items():
        data[module] = {}
        for table in tables:
            if table == 'financial_summary':
                cur.execute("SELECT COALESCE(SUM(total_ventas), 0), COALESCE(SUM(total_compras), 0), COALESCE(SUM(presupuesto), 0) FROM financial_summary")
                ventas, compras, presupuesto = cur.fetchone()
                final = (ventas + presupuesto) - compras
                data[module] = {
                    'Total Ventas': ventas,
                    'Total Compras': compras,
                    'Presupuesto': presupuesto,
                    'Presupuesto Final': final
                }
            else:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                count = cur.fetchone()[0]
                display = DISPLAY_NAMES.get(table, table)
                data[module][display] = count

    cur.close()
    conn.close()
    return data

def generate_charts(data):
    charts = {}
    for module, tables in data.items():
        fig = go.Figure(data=[
            go.Bar(name=label, x=[label], y=[value])
            for label, value in tables.items()
        ])
        fig.update_layout(title_text=f'Estadísticas del módulo {module}',
                          xaxis_title='Categoría',
                          yaxis_title='Valor')
        charts[module] = pio.to_html(fig, full_html=False)
    return charts

@app.route('/')
def index():
    data = get_table_counts()
    return render_template("index.html", data=data)

@app.route('/<module>')
def show_module(module):
    data = get_table_counts()
    chart = generate_charts(data).get(module, '')
    return render_template("module.html", module=module, tables=data.get(module, {}), chart=chart)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
