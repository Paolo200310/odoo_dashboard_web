
from flask import Flask, render_template
import psycopg2
import plotly.graph_objs as go
import plotly.io as pio

app = Flask(__name__)

DB_PARAMS = {
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': '5432'
}

MODULES = {
    'Academic': {
        'academic_student': 'Estudiantes Totales',
        'academic_subject': 'Materias'
    },
    'Administrativo': {
        'hr_employee': 'Empleados',
        'hr_department': 'Departamentos'
    },
    'Transaccional': {
        'purchase_order': 'Órdenes de Compra',
        'sale_order': 'Órdenes de Venta'
    },
    'Financiero': {
        'ventas': 'Total Ventas',
        'compras': 'Total Compras',
        'presupuesto': 'Presupuesto'
    }
}

def get_table_counts():
    conn = psycopg2.connect(**DB_PARAMS)
    cur = conn.cursor()
    data = {}

    for module, tables in MODULES.items():
        data[module] = {}
        if module != 'Financiero':
            for table, label in tables.items():
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                count = cur.fetchone()[0]
                data[module][label] = count
        else:
            cur.execute("SELECT SUM(total_ventas), SUM(total_compras), SUM(presupuesto) FROM financial_summary")
            result = cur.fetchone()
            total_ventas = result[0] or 0
            total_compras = result[1] or 0
            presupuesto = result[2] or 0
            presupuesto_final = (total_ventas + presupuesto) - total_compras
            data[module] = {
                'Total Ventas': total_ventas,
                'Total Compras': total_compras,
                'Presupuesto': presupuesto,
                'Presupuesto Final': presupuesto_final
            }
    cur.close()
    conn.close()
    return data

def generate_charts(data):
    charts = {}
    for module, tables in data.items():
        fig = go.Figure(data=[go.Bar(name=label, x=[label], y=[value])
                              for label, value in tables.items()])
        fig.update_layout(title_text=f'Estadísticas del módulo {module}',
                          xaxis_title='Categoría',
                          yaxis_title='Cantidad o Valor')
        charts[module] = pio.to_html(fig, full_html=False)
    return charts

@app.route('/')
def index():
    data = get_table_counts()
    totals = {module: sum(val for val in values.values() if isinstance(val, (int, float))) for module, values in data.items()}
    return render_template("index.html", data=data, totals=totals)

@app.route('/<module>')
def show_module(module):
    data = get_table_counts()
    chart = generate_charts(data).get(module, '')
    return render_template("module.html", module=module, tables=data.get(module, {}), chart=chart)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
