
from flask import Flask, render_template
import psycopg2
import plotly.graph_objs as go
import plotly.io as pio

app = Flask(__name__)

DB_PARAMS = {
    'dbname': 'db_odoo',
    'user': 'odoo',
    'password': 'odoo',
    'host': 'localhost',
    'port': '5432'
}

MODULES = {
    'Academic': ['academic_student', 'academic_subject'],
    'Administrativo': ['hr_employee', 'hr_department'],
    'Transaccional': ['purchase_order', 'sale_order'],
    'Financiero': ['sale_order', 'purchase_order', 'financial_summary']
}

TABLE_LABELS = {
    'academic_student': 'Estudiantes Totales',
    'academic_subject': 'Materias',
    'hr_employee': 'Empleados',
    'hr_department': 'Departamentos',
    'purchase_order': 'Compras Realizadas',
    'sale_order': 'Ventas Realizadas',
    'financial_summary': 'Presupuestos Registrados'
}

def get_table_counts():
    conn = psycopg2.connect(**DB_PARAMS)
    cur = conn.cursor()
    data = {}
    for module, tables in MODULES.items():
        data[module] = {}
        for table in tables:
            if module == 'Financiero' and table == 'financial_summary':
                cur.execute("SELECT COALESCE(SUM(budget), 0) FROM financial_summary")
                count = cur.fetchone()[0]
                data[module]['Presupuesto Registrado'] = count
            else:
                cur.execute(f"SELECT COUNT(*) FROM {table}")
                count = cur.fetchone()[0]
                label = TABLE_LABELS.get(table, table)
                data[module][label] = count
    # Para módulo financiero, obtener montos reales
    cur.execute("SELECT COALESCE(SUM(amount_total), 0) FROM sale_order")
    total_ventas = cur.fetchone()[0]
    cur.execute("SELECT COALESCE(SUM(amount_total), 0) FROM purchase_order")
    total_compras = cur.fetchone()[0]
    cur.execute("SELECT COALESCE(SUM(budget), 0) FROM financial_summary")
    presupuesto = cur.fetchone()[0]
    total_presupuesto = total_ventas + presupuesto - total_compras
    data['Financiero']['Total Ventas'] = total_ventas
    data['Financiero']['Total Compras'] = total_compras
    data['Financiero']['Presupuesto'] = presupuesto
    data['Financiero']['Presupuesto Final'] = total_presupuesto
    cur.close()
    conn.close()
    return data

def generate_charts(data):
    charts = {}
    for module, tables in data.items():
        if module == 'Financiero':
            keys = ['Total Ventas', 'Presupuesto', 'Total Compras']
            values = [tables.get(k, 0) for k in keys]
            fig = go.Figure(data=[go.Bar(x=keys, y=values)])
        else:
            fig = go.Figure(data=[go.Bar(name=table, x=[table], y=[count])
                                  for table, count in tables.items()])
        fig.update_layout(title_text=f'Registros del módulo {module}',
                          xaxis_title='Elemento',
                          yaxis_title='Cantidad')
        charts[module] = pio.to_html(fig, full_html=False)
    return charts

@app.route('/')
def index():
    data = get_table_counts()
    return render_template("index.html", data=data)

@app.route('/<module>')
def show_module(module):
    data = get_table_counts()
    chart = generate_charts(data).get(module, '')
    return render_template("module.html", module=module, tables=data.get(module, {}), chart=chart)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
